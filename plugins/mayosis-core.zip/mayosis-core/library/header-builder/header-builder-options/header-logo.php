<?php

Mayosis_Option::add_section( 'header_logo', array(
	'title'       => __( 'Logo', 'mayosis' ),
	'panel'       => 'header',
	//'description' => __( 'This is the section description', 'mayosis' ),
) );



Mayosis_Option::add_field( 'mayo_config',  array(
	'type'        => 'image',
	'settings'     => 'main_logo',
	'label'       => __( 'Logo image', 'mayosis' ),
	'section'     => 'header_logo',
	'default'     => get_template_directory_uri().'/images/logo.png',
	'transport' => 'auto',
));

Mayosis_Option::add_field( 'mayo_config',  array(
	'type'        => 'image',
	'settings'     => 'mobile-logo-image',
	'label'       => __( 'Mobile Logo Image', 'mayosis' ),
	'description' => __( 'Upload different logo on mobile', 'mayosis' ),
	'section'     => 'header_logo',
));

Mayosis_Option::add_field( 'mayo_config',  array(
	'type'        => 'image',
	'settings'     => 'sticky_logo',
	'label'       => __( 'Sticky Header Logo Image', 'mayosis' ),
	'description' => __( 'Upload different logo on sticky header', 'mayosis' ),
	'section'     => 'header_logo',
));

Mayosis_Option::add_field( 'mayo_config',  array(
'type'        => 'image',
'settings'    => 'favicon-upload',
'label'       => esc_attr__( 'Favicon', 'mayosis' ),
'description' => esc_attr__( 'Recommanded 80 X 80px', 'mayosis' ),
'section'     => 'header_logo',
'default'     => get_template_directory_uri() . '/images/fav.png',
));
 