<?php

Mayosis_Option::add_section( 'header_search', array(
	'title'       => __( 'Search', 'mayosis' ),
	'panel'       => 'header',
) );


Mayosis_Option::add_field( '',
	array(
		'type'     => 'custom',
		'settings' => 'custom-title-search',
		'label'    => __( '', 'mayosis' ),
		'section'  => 'header_search',
		'default'  => '<div class="options-title">Search Icon Options</div>',
	)
);


Mayosis_Option::add_field( 'mayo_config',  array(
	                'type'        => 'radio-image',
                	'settings'    => 'search_style',
                	'label'       => esc_html__( 'Search Style', 'mayosis' ),
                	'section'     => 'header_search',
                	'default'     => 'one',
                	'priority'    => 10,
                	'choices'     => array(
                		'one'   => get_template_directory_uri() . '/images/search-style-1.png',
                		'two' => get_template_directory_uri() . '/images/search-style-2.png',
                	),
));



Mayosis_Option::add_field( 'mayo_config',  array(
    
                        'type'        => 'radio-buttonset',
                    	'settings'    => 'search_behaviour',
                    	'label'       => __( 'Search Beahviour', 'mayosis' ),
                    	'section'     => 'header_search',
                    	'default'     => 'dropdown',
                    	'priority'    => 10,
                    	'choices'     => array(
                    		'dropdown'   => esc_attr__( 'Dropdown', 'mayosis' ),
                    		'collapse' => esc_attr__( 'Collapse', 'mayosis' ),
                    		'fullscreen' => esc_attr__( 'Fullscreen Overlay', 'mayosis' ),
                    	),
                    	'required'    => array(
                        array(
                            'setting'  => 'search_style',
                            'operator' => '==',
                            'value'    => 'one',
                                ),
                            ),
    
    ));
    
    Mayosis_Option::add_field( 'mayo_config',  array(
    'type'        => 'dimension',
	'settings'    => 'header-search-border-radius',
	'label'       => esc_attr__( 'Search Form Border Radius (px)', 'mayosis' ),
	'section'     => 'header_search',
	'output'      => array(
            array(
                'element'  => '.stylish-input-group input.dm_search',
                'property' => 'border-radius',
            ),
            
        ),
	'default'     => '3px',
        ));
Mayosis_Option::add_field( '',
	array(
		'type'     => 'custom',
		'settings' => 'custom-title-search-two',
		'label'    => __( '', 'mayosis' ),
		'section'  => 'header_search',
		'default'  => '<div class="options-title">Search Form Options</div>',
	)
);

Mayosis_Option::add_field( 'mayo_config',  array(
    'type'        => 'dimension',
	'settings'    => 'header-search-form-width',
	'label'       => esc_attr__( 'Search Form Width (px or %)', 'mayosis' ),
	'section'     => 'header_search',
	'output'      => array(
            array(
                'element'  => '.header-search-form',
                'property' => 'width',
            ),
        ),
	'default'     => '360px',
        ));
        
        
Mayosis_Option::add_field( 'mayo_config',  array(
    'type'        => 'dimension',
	'settings'    => 'header-search-form-height',
	'label'       => esc_attr__( 'Search Form height (px)', 'mayosis' ),
	'section'     => 'header_search',
	'output'      => array(
            array(
                'element'  => '.header-search-form input[type=search], .header-search-form input[type=text], .header-search-form select,.header-search-form .search-btn,
        .header-search-form .mayosel-select,.header-search-form .search-btn::after',
                'property' => 'height',
            ),
            
            array(
                'element'  => '.header-search-form input[type=search], .header-search-form input[type=text], .header-search-form select,.header-search-form .search-btn,
        .header-search-form .mayosel-select,.header-search-form .search-btn::after',
                'property' => 'max-height',
            ),
            
            array(
                'element'  => '.header-search-form .search-btn::after',
                'property' => 'line-height',
            ),
        ),
	'default'     => '40px',
        ));
        
Mayosis_Option::add_field( 'mayo_config',  array(
    
                        'type'        => 'radio-buttonset',
                    	'settings'    => 'search_form_style',
                    	'label'       => __( 'Search Form Style', 'mayosis' ),
                    	'section'     => 'header_search',
                    	'default'     => 'standard',
                    	'priority'    => 10,
                    	'choices'     => array(
                    		'standard'   => esc_attr__( 'Standard', 'mayosis' ),
                    		'ghost' => esc_attr__( 'Ghost', 'mayosis' ),
                    	),
    
    ));