<?php
/**
 * Get Template Settings
 *
 * @since  2.5
 */
 
 $templateautomationtype= get_theme_mod( 'product_template_autmation_main','single-download');
 
 
if ($templateautomationtype == 'allcat'):{
 
//all cat options
add_action('add_meta_boxes', 'mayosis_product_template_functions', 1);

function mayosis_product_template_functions() {
    global $post;
    $wholesitetem= get_theme_mod( 'whole_site_product_template','photo');
    if ( 'download' == $post->post_type && 0 != count( get_page_templates( $post ) ) && get_option( 'page_for_posts' ) != $post->ID ) {
          if( $wholesitetem == 'photo' ){
             $post->page_template = "download-photo-template.php";
          } elseif( $wholesitetem == 'multi' ) {
               $post->page_template = "prime-download-template.php";
               
          } elseif( $wholesitetem == 'full' ) {
              $post->page_template = "full-width-download-template.php";
              
          } elseif( $wholesitetem == 'narrow' ) {
              
        $post->page_template = "narrow-download-template.php";
          }
    }
}

}
 endif;