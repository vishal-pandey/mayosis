<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}
$download_id = get_the_ID();

?>


    <div class="col-md-12 col-xs-12 single_main_header_products">
        <div class="single--post--content">
            <?php get_template_part( 'includes/prime-product-header-layout' ); ?>
        </div>
    </div>



