 <div  class="mobile--nav-menu">
       <div class="top-part-mobile to-flex-row">
            <div class="to-flex-col th-col-left">
                <?php mayosis_header_elements('header_mobile_sidebar_left'); ?>
            </div>
            
            <div class="to-flex-col th-col-right">
                <?php mayosis_header_elements('header_mobile_sidebar_right'); ?>
            </div>
        </div>
        
        <div class="mobile-menu-main-part">
            <div class="col-sm-12 col-xs-12">
                 <?php mayosis_header_elements('header_mobile_elements_sidebar_main'); ?>
            </div>
        </div>
       
       
        <div class="bottom-part-mobile to-flex-row">
            <div class="to-flex-col th-col-left">
                <?php mayosis_header_elements('header_mobile_sidebar_left'); ?>
                <?php mayosis_header_elements('header_mobile_sidebar_bottom_left'); ?>
            </div>
            
            <div class="to-flex-col th-col-right">
                <?php mayosis_header_elements('header_mobile_sidebar_bottom_right'); ?>
            </div>
        </div>
    </div>
    <div class="overlaymobile"></div>
     <ul  class="mobile-nav">
     <li class="burger"><span></span></li>
     </ul>