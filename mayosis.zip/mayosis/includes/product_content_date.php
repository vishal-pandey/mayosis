<?php
defined('ABSPATH') or die(); ?>
	
 <span class="toolspan"><?php esc_html_e("on","mayosis"); ?> <?php echo esc_html(get_the_date()); ?></span>