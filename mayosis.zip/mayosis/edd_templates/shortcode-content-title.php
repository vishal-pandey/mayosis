<div class="product-meta">
	<?php get_template_part( 'includes/product-meta' ); ?>
							
	</div>