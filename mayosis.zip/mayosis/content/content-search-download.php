<?php
/**
 * @package mayosis
 */
  if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}
?>
<?php
                    $taxquery=array();
                    if(isset($_GET['download_cats']) && $_GET['download_cats'] !== 'all'){
                        $download_category = $_GET['download_cats'];

                        $taxquery =    array(
                            array(
                                'taxonomy' => 'download_category',
                                'field'    => 'slug',
                                'terms'    => $download_category
                                )
                            );
                    }
                    
                    $paged=( get_query_var( 'paged')) ? get_query_var( 'paged') : 1;
                    
                        
                            $argument = array(
                            's'            => get_search_query(),
                            'order'     => 'DESC',
                            'post_type' => 'download',
                            'paged'     => $paged,
                            'tax_query' => $taxquery
                            );
            
                    $wp_query = new WP_Query(); $wp_query->query($argument);
                    
                    if($wp_query->have_posts()){
                        while ( $wp_query->have_posts() ) : $wp_query->the_post(); ?>
  <div class="col-md-4">
	<div class="grid_dm ribbon-box group edge">
		<div class="product-box">
			<?php
            $postdate = get_the_time('Y-m-d');   // Post date
            $postdatestamp = strtotime($postdate);   // Timestamped post date
            $newness = get_theme_mod('dm_days_products_new', '30');  // Newness in days

            if ((time() - (60 * 60 * 24 * $newness)) < $postdatestamp) { // If the product was published within the newness time frame display the new badge
                echo '
			<div class="wrap-ribbon left-edge point lblue">
				<span>'. esc_html__('New', 'mayosis') .'</span>
			</div>';
            }
             ?>
			<figure class="mayosis-fade-in">
				<?php
                                // display featured image?
                                if ( has_post_thumbnail() ) :
                                    the_post_thumbnail( 'full', array( 'class' => 'img-responsive' ) );
                                endif; 

                            ?>
				<figcaption>
					<div class="overlay_content_center">
						<?php     get_template_part( 'includes/product-hover-content-top' ); ?>
						<div class="product_hover_details_button">
							<a href="
								<?php the_permalink(); ?>" class="button-fill-color">
								<?php esc_html_e('View Details', 'mayosis'); ?>
							</a>
						</div>
						<?php $demo_link = get_post_meta($post->ID, 'demo_link', true); ?>
						<?php if ( $demo_link ) { ?>
						<div class="product_hover_demo_button">
							<a href="
								<?php echo esc_url($demo_link); ?>" class="live_demo_onh" target="_blank">
								<?php esc_html_e('Live Demo', 'mayosis'); ?>
							</a>
						</div>
						<?php } ?>
						<?php     get_template_part( 'includes/product-hover-content-bottom' ); ?>
					</div>
				</figcaption>
			</figure>
			<div class="product-meta">
				<?php get_template_part( 'includes/product-meta' ); ?>
			</div>
		</div>
		<!-- .product box -->
	</div>
</div>
<?php endwhile; ?>
<?php }
                    else { ?>
<h5>
	<?php esc_html_e("No product found","mayosis"); ?>
</h5>
<?php } ?>
<div class="col-md-12">
	<?php mayosis_page_navs(); ?>
</div>